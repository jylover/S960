sudo make rmmod
sudo make install
reboot 


changenotes: 
1. fix the reboot not init bug
