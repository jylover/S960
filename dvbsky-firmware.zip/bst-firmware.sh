#!/bin/bash

cp ./dvb-demod-m88ds3103.fw /lib/firmware/

echo "Copy Firmware for DVBSky card/box."
