#!bin/sh

insmod ./drivers/dvb-usb-avl6762_x86_64_4.10.0-32-generic.ko
insmod ./drivers/dvb-usb-avl6381_x86_64_4.10.0-32-generic.ko
insmod ./drivers/avl6812_x86_64_4.10.0-32-generic.ko
insmod ./drivers/dvb-usb-runqida-si216x_x86_64_4.10.0-32-generic.ko
insmod ./drivers/dvb-usb-m88dd3000_x86_64_4.10.0-32-generic.ko
insmod ./drivers/dvb-usb-runqida_x86_64_4.10.0-32-generic.ko
