#!bin/sh

rmmod -f dvb_usb_m88dd3000 |rmmod -f dvb_usb_runqida_si216x | rmmod -f avl6812 |  rmmod -f dvb_usb_avl6381 | rmmod -f  dvb_usb_runqida |rmmod -f dvb_usb_avl6762

