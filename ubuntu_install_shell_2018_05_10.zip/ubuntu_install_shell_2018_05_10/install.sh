#!bin/sh

export USER_DEFINED_KERNEL_VERSION="$(uname -r | cut -d- -f1)"
CURKERNEL_VER="$(uname -m)"_${USER_DEFINED_KERNEL_VERSION}

echo "Current kernel version: ${CURKERNEL_VER}"

modprobe dvb-usb
lsmod | grep dvb_

insmod ./drivers/dvb-usb-avl6762_${CURKERNEL_VER}.ko
insmod ./drivers/dvb-usb-avl6381_${CURKERNEL_VER}.ko
insmod ./drivers/avl6812_${CURKERNEL_VER}.ko
insmod ./drivers/dvb-usb-runqida-si216x_${CURKERNEL_VER}.ko
insmod ./drivers/dvb-usb-m88dd3000_${CURKERNEL_VER}.ko
insmod ./drivers/dvb-usb-atbm888x_${CURKERNEL_VER}.ko
insmod ./drivers/dvb-usb-runqida_${CURKERNEL_VER}.ko
insmod ./drivers/dvb-usb-mn88436_${CURKERNEL_VER}.ko
echo After driver installed!
lsmod | grep dvb_
