#!bin/sh

#rm files from disk

echo libdirectory: /lib/modules/$(uname -r)/kernel/drivers/media/usb/dvb-usb/runqida

rm -fr /lib/modules/$(uname -r)/kernel/drivers/media/usb/dvb-usb/runqida

rmmod -f dvb_usb_m88dd3000 |rmmod -f dvb_usb_atbm888x |rmmod -f dvb_usb_runqida_si216x | rmmod -f avl6812 \
	| rmmod -f dvb-usb-mn88436 |  rmmod -f dvb_usb_avl6381 | rmmod -f  dvb_usb_runqida |rmmod -f dvb_usb_avl6762 

lsmod | grep dvb_

