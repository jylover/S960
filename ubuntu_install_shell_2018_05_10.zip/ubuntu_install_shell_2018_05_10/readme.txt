1. remove old driver
  拔出USB设备， 执行：
  sudo sh ./unintsall.sh
2. 安装新驱动：
sudo make install
reboot 


changenotes: 
1. fix the reboot not init bug
